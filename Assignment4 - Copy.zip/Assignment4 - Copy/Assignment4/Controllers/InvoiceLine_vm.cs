﻿using Assignment4.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Assignment4.Controllers
{
    public class InvoiceLineBase
    {
        public InvoiceLineBase()
        {
           
        }

        [Key]
        [Display(Name = "Invoice line Id")]
        public int InvoiceLineId { get; set; }

        [Display(Name = "Track Id")]
        public int TrackId { get; set; }

        [Column(TypeName = "numeric")]
        [Display(Name = "Unit price")]
        public decimal UnitPrice { get; set; }

        public int Quantity { get; set; }

        [Column(TypeName = "numeric")]
        [Display(Name = "Item Total")]
        public decimal ItemTotal { get; set; }
    }

    public class InvoiceLineWithDetail : InvoiceLineBase
    {
        public InvoiceLineWithDetail()
        {

        }

        [Required]
        [StringLength(200)]
        [Display(Name = "Track name, Artist")]
        public string TrackName { get; set; }

        [StringLength(220)]
        //[Display(Name = "Track name, Artist")]
        public string TrackComposer { get; set; }

        [Required]
        [StringLength(160)]
        [Display(Name = "Album, Composer(s)")]
        public string TrackAlbumTitle { get; set; }

        [StringLength(120)]
        //[Display(Name = "Album, Composer(s)")]
        public string TrackAlbumArtistName { get; set; }

        [StringLength(120)]
        //[Display(Name = "Album, Composer(s)")]
        public string TrackMediaTypeName { get; set; }
    }

}
﻿using Assignment4.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Assignment4.Controllers
{
    public class InvoiceBase
    {
        public InvoiceBase()
        {

        }

        [Key]
        [Display(Name = "Invoice number")]
        public int InvoiceId { get; set; }

        [Display(Name = "Customer Id")]
        public int CustomerId { get; set; }

        [Display(Name = "Invoice date")]
        public DateTime InvoiceDate { get; set; }

        [StringLength(70)]
        [Display(Name = "Billing address")]
        public string BillingAddress { get; set; }

        [StringLength(40)]
        [Display(Name = "Billing city")]
        public string BillingCity { get; set; }

        [StringLength(40)]
        [Display(Name = "Billing state")]
        public string BillingState { get; set; }

        [StringLength(40)]
        [Display(Name = "Billing country")]
        public string BillingCountry { get; set; }

        [StringLength(10)]
        [Display(Name = "Postal code")]
        public string BillingPostalCode { get; set; }

        [Column(TypeName = "numeric")]
        [Display(Name = "Invoice total")]
        public decimal Total { get; set; }

        
    }

    

    public class InvoiceWithDetail : InvoiceBase
    {
        public InvoiceWithDetail()
        {
            InvoiceLines = new List<InvoiceLineWithDetail>();
        }        

        [Display(Name = "Customer name")]
        public string CustomerLastName { get; set; }

        //[Display(Name = "Customer name")]
        public string CustomerFirstName { get; set; }

        //[Display(Name = "Customer name")]
        public string CustomerCity { get; set; }

        //[Display(Name = "Customer name")]
        public string CustomerState { get; set; }

        [Display(Name = "Sales representative")]
        public string CustomerEmployeeFirstName { get; set; }

        //[Display(Name = "Sales representative")]
        public string CustomerEmployeeLastName { get; set; }

        public IEnumerable<InvoiceLineWithDetail> InvoiceLines { get; set; }
    }
}